'use strict';
 
function toggleMenu(){
	var menuDrawer = document.getElementById('menu-drawer');
	var menuButton = document.querySelector('.menu-btn');
	var arr = '';
	
	if(menuDrawer.style.display == 'none' || menuDrawer.style.display == '') {
		menuDrawer.style.display = 'block';
		
		//menuButton.classList.toggle('is-open');
	
		arr = menuButton.className.split(' ');
		arr.push('is-open');
		arr = arr.join(" ");
		menuButton.className = arr;
		return;
	}else{
		menuDrawer.style.display = 'none';
		
		//menuButton.classList.toggle('is-open');
		
		arr = menuButton.className.split(" ");
		arr.pop();
		arr = arr.join(" ");
		menuButton.className = arr;
		return;		
	}
}

function toggleMenu2(){
	var menuDrawer = document.getElementById('menu-drawer');
	var menuButton = document.querySelector('.menu-btn');
	var arr = '';
	
	if(menuDrawer.style.left == '-300px' || menuDrawer.style.left == '') {
		menuDrawer.style.left = '0';
		
		//menuButton.classList.toggle('is-open');
	
		arr = menuButton.className.split(' ');
		arr.push('is-open');
		arr = arr.join(" ");
		menuButton.className = arr;
		return;
	}else{
		menuDrawer.style.left = '-300px';
		
		//menuButton.classList.toggle('is-open');
		
		arr = menuButton.className.split(" ");
		arr.pop();
		arr = arr.join(" ");
		menuButton.className = arr;
		return;		
	}
}


function toggleElem(id) {
  var elem = document.getElementById(id);
  if(elem.style.display == 'none'/* || menuDrawer.style.display == ''*/) {
    elem.style.display = 'block';
	return;
  }else{
    elem.style.display = 'none';
  }
}

function toggleModal(id) {
  var elem = document.getElementById(id);
  if(elem.style.display == 'none' || menuDrawer.style.display == '') {
    elem.style.display = 'table';
  }else{
    elem.style.display = 'none';
  }
}
/*
setPro('header', 'height', 'menu-drawer', 'top');
setPro('header', 'height', 'slider-section', 'marginTop');*/
setPro('form-left-column', 'height', 'textarea', 'height');
window.addEventListener("resize", function(){
	/*setPro('header', 'height', 'menu-drawer', 'top');
	setPro('header', 'height', 'slider-section', 'marginTop');*/
	setPro('form-left-column', 'height', 'textarea', 'height');
});

//alert('the height of header is ' + getComputedStyle(document.getElementById('header')).height)


/*
*function setPro()
* This sets the css property of an element (target) equal to the css property value of another element (capture)
* It essentially grabs the css property value of the "capture" and uses it as the property value of "target"

*FOR EXAMPLE:*
*
* Since the height of header is "auto" (determined by its descendants)
* If we set the "top" property of our nav-bar to an 'absolute' value, it would overlap (definitely not what we want).
* So, it can help set the value of the "top" property of the nav-bar to the value of the "height" property of the header
* this helps to prevent overlapping.
*/
function setPro(captureId, captureCSS, targetId, targetCSS, targetPull) {
	targetPull = (targetPull) ? targetPull : '';
	var theCapture = document.getElementById(captureId);
	var theTarget = document.getElementById(targetId);
	theTarget.style[targetCSS] = targetPull + getComputedStyle(theCapture)[captureCSS];
}


function validateForm() {
	var elem, fname, email, subject, message, emptyElem, errorMessage;
	elem = document.forms['contact-form'].elements;
	fname = elem['fname'];
	email = elem['email'];
	subject = elem['subject'];
	message = elem['message'];
	//emptyElem = fname.value && email.value && message.value;
	emptyElem = fname.value.length < 1 ? fname : email.value.length < 1  ? email : message.value.length < 1  ? message : 'good';
	
	reverse_color(elem);
	
	if(emptyElem == 'good') {
		if(fname.value.length > 5 && fname.value !== 'name too small') {
			if(/^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/.test(email.value)) {
				//submitted
				return true;
			}else {
				email.value = 'enter a valid email';
				email.focus();
				email.style.color = 'red';
				return false;
			}
		}else {
			fname.value = 'name too small';
			fname.focus();
			fname.style.color = 'red';
			return false;
		}
	}else {		
		emptyElem.focus();
		//emptyElem.style.backgroundColor = "white";
		emptyElem.style.color = "red"
		return false;
	}
	
	function reverse_color(obj) {
		for(var i = 0; i < obj.length - 1; i++) {
			if(obj[i].style.color == 'red') {
				obj[i].style.color = 'gray'
			}
		}
	}
}


function validateIt(ourform, obj) {
   var input, genderSpan, termsSpan, rememberSpan;
    input = document.forms[ourform].elements;
    password = document.getElementById('password');
    genderSpan = document.getElementById('gender-span');
    termsSpan = document.getElementById('terms-span');
    rememberSpan = document.getElementById('remember-span');
    
    if(obj) {
        //texts fields
        if(obj.type == 'text' || obj.type == 'email' || obj.type == 'password'){
			if(!obj.value.length){
			//alert(obj.value.length)
                obj.nextElementSibling.style.display = 'block';
                obj.nextElementSibling.innerHTML = 'This field is required';
                obj.focus();
            }else{
				if(obj.value.length >= 1 && obj.value.length < 3){
					obj.nextElementSibling.style.display = 'block';
					obj.nextElementSibling.innerHTML = 'Length too small';
					obj.focus();
				}else{
					obj.nextElementSibling.style.display = 'none';                
				}
			}
        }
        
        //email field
        if(obj.type == 'email' && obj.value.length > 3) {
            if(/^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/.test(obj.value)) {
                obj.nextElementSibling.style.display = 'none';
            }else {
                obj.nextElementSibling.style.display = 'block';
                obj.nextElementSibling.innerHTML = 'Enter a valid email address';
                obj.focus();
            }
        }
        
        //password field
        if((obj.type == 'password' || obj.type == 'text') && (obj.id == 'password' || obj.id == 'password2')) {
            if(obj.value.length >= 1 && obj.value.length < 6) {
                obj.nextElementSibling.style.display = 'block';
                obj.nextElementSibling.innerHTML = 'Password should be atleast 6 characters long';
                obj.focus();
            }else if(obj.value.length >= 6) {
                obj.nextElementSibling.style.display = 'none';
            }
        }
        
        //confirm-password
        if(obj.type == 'password' && obj.id == 'confirm-password') {
            if(obj.value) {
				if(obj.value == password.value) {
					obj.nextElementSibling.style.display = 'none';                
				}else {
					obj.nextElementSibling.style.display = 'block';
					obj.nextElementSibling.innerHTML = 'Password mismatch';
					obj.focus();
				}
			}
        }
        
        //checkbox
        if(obj.type == 'checkbox'){
            if(obj.checked) {
                if(obj.name == 'policy-agreement'){
					termsSpan.style.display = 'none';
				}
            }else {
                if(obj.name == 'policy-agreement'){
					termsSpan.style.display = 'block';
					termsSpan.innerHTML = 'Accept the terms to continue';
				}
            }
        }
    }else{
        //validate all
        for(var i = 0; i < input.length - 1; i++) {
            
            //checks the text, email and password fields
            if(input[i].type == 'text' || input[i].type == 'email' || input[i].type == 'password') {
               //checks if they are empty
                if(input[i].value.length < 1) {
                    input[i].nextElementSibling.style.display = 'block';
                    input[i].nextElementSibling.innerHTML= 'This field is required';
					input[i].focus();
					return false;
                }
				
				//checks if they too small
				if(input[i].value.length >= 1 && input[i].value.length < 3){
					input[i].nextElementSibling.style.display = 'block';
					input[i].nextElementSibling.innerHTML = 'Length too small';
					input[i].focus();
					return false;
				}
					
				//checks email
				if(input[i].type == 'email' && input[i].value.length > 1) {
					if(!(/^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/.test(input[i].value))) {
						input[i].nextElementSibling.style.display = 'block';
						input[i].nextElementSibling.innerHTML = 'Enter a valid email address';
						input[i].focus();
						return false;
					}
				
				}
				
				//password field
				if((input[i].type == 'password' || input[i].type == 'text') && (input[i].id == 'password' || input[i].id == 'password2')) {
					if(input[i].value.length >= 1 && input[i].value.length < 6) {
						input[i].nextElementSibling.style.display = 'block';
						input[i].nextElementSibling.innerHTML = 'Password should be atleast 6 characters long';
						input[i].focus();
						return false;
					}
				}
				
				//confirm-password
				if(input[i].type == 'password' && input[i].id == 'confirm-password') {
					if(input[i].value) {
						if(input[i].value != password.value) {
							input[i].nextElementSibling.style.display = 'block';
							input[i].nextElementSibling.innerHTML = 'Password mismatch';
							input[i].focus();
							return false;
						}
					}
				}
			}
			
			//check box for terms and condition
			if(input[i].type == 'checkbox') {
				if(input[i].checked == false && input[i].name == 'policy-agreement') {
					termsSpan.style.display = 'block';
					termsSpan.innerHTML = 'Accept the terms to continue';
					return false;
				}
			}
			//end
		}//end of loop
    }//end of else    
    return true;
} 
